package com.fongmi.android.tv.api.loader;

import com.caoccao.javet.interop.NodeRuntime;

import com.fongmi.android.tv.App;
import com.fongmi.android.tv.api.config.VodConfig;
import com.fongmi.android.tv.bean.Site;

import com.fongmi.javetds.NodeServerController;

import com.github.catvod.crawler.Spider;
import com.github.catvod.crawler.SpiderNull;
import com.github.catvod.utils.Path;
import com.github.catvod.utils.log.LOG;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class NodeLoader {
    private static final String TAG = "NodeJs";
    private static NodeLoader instance;
    private final ConcurrentHashMap<String, Spider> spiders;
    private String recent;

    public NodeLoader() {
        spiders = new ConcurrentHashMap<>();
    }

    public static NodeLoader get() {
        synchronized (VodConfig.class) {
            if (instance == null) {
                instance = new NodeLoader();
            }
        }
        return instance;
    }

    public void clear() {
        for (Spider spider : spiders.values()) spider.destroy();
        spiders.clear();
    }

    public void setRecent(String recent) {
        this.recent = recent;
    }

    public Spider getSpider(String key, String name, String ext) {
        try {
            NodeRuntime ctx = getNode().getNodeRuntime();
            if (spiders.containsKey(key)) return spiders.get(key);
            Spider spider = new com.fongmi.javetds.Spider(key, name, ctx);
            spider.init(App.get(), ext);
            spiders.put(key, spider);
            return spider;
        } catch (Throwable e) {
            return new SpiderNull();
        }
    }

    public NodeServerController getNode() {
        NodeServerController ctrl = NodeServerController.getInstance();
        if (ctrl.getNodeRuntime() == null || !ctrl.isRunning()) {
            final CountDownLatch countDownLatch = new CountDownLatch(1);
            App.execute(() -> {
                ctrl.startServerIfNeeded(Path.rootPath() + "/tvbox/drpy-node", new NodeServerController.StateListener() {
                    @Override
                    public void state(boolean running) {
                        if (running) {
                            countDownLatch.countDown();
                        }
                    }
                });
            });
            try {
                if (!countDownLatch.await(5, TimeUnit.SECONDS)) {
                    LOG.e(TAG, "等待 node 启动超时");
                }
            } catch (InterruptedException e) {
                LOG.e(TAG, "等待 node 启动被中断:" + e);
                Thread.currentThread().interrupt();
            }
        }
        return ctrl;
    }

    private Spider find(Map<String, String> params) {
        if (!params.containsKey("siteKey")) return spiders.get(recent);
        Site site = VodConfig.get().getSite(params.get("siteKey"));
        return site.isEmpty() ? new SpiderNull() : VodConfig.get().getSpider(site);
    }

    public Object[] proxyInvoke(Map<String, String> params) {
        try {
            return find(params).proxyLocal(params);
        } catch (Throwable e) {
            e.printStackTrace();
            return null;
        }
    }

}
