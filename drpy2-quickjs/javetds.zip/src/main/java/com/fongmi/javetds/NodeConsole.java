package com.fongmi.javetds;

import com.caoccao.javet.annotations.V8Function;
import com.caoccao.javet.values.V8Value;
import com.github.catvod.utils.log.LOG;

public class NodeConsole {
    private static final String TAG = "NodeJs";

    @V8Function
    public void log(Object... args) {
        LOG.e(TAG, getString(args));
    }

    @V8Function
    public void debug(Object... args) {
        LOG.e(TAG, getString(args));
    }

    @V8Function
    public void info(Object... args) {
        LOG.e(TAG, getString(args));
    }

    @V8Function
    public void warn(Object... args) {
        LOG.e(TAG, getString(args));
    }

    @V8Function
    public void error(Object... args) {
        LOG.e(TAG, getString(args));
    }

    private String getString(Object... args) {
        if (args == null) return "null";
        try {
            StringBuilder sb = new StringBuilder();
            for (Object arg : args) {
                Object nodeObj;
                if (arg instanceof V8Value) {
                    nodeObj = V8ValueConverter.toJavaObject((V8Value) arg);
                } else nodeObj = arg;
                String log = V8ValueConverter.stringify(nodeObj);
                sb.append(log);
                if (!log.matches(".*\n")) {
                    sb.append(" ");
                }
            }
            return sb.toString().trim().replaceAll("\\\\n", "\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "null";
    }

}

