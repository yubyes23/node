package com.fongmi.javetds;

import android.content.Context;
import android.util.Base64;

import com.caoccao.javet.exceptions.JavetException;
import com.caoccao.javet.interop.NodeRuntime;
import com.caoccao.javet.values.V8Value;
import com.caoccao.javet.values.reference.IV8ValuePromise;
import com.caoccao.javet.values.reference.V8ValueArray;
import com.caoccao.javet.values.reference.V8ValueFunction;
import com.caoccao.javet.values.reference.V8ValueObject;
import com.caoccao.javet.values.reference.V8ValuePromise;
import com.github.catvod.Proxy;
import com.github.catvod.utils.log.LOG;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class Spider extends com.github.catvod.crawler.Spider {
    private final String sourceKey;
    private final String modulePath;
    private final NodeRuntime nodeRuntime;
    private final ConcurrentHashMap<String, String> queryMap;
    private final ConcurrentHashMap<String, Object> paramsMap;

    public Spider(String key, String path, NodeRuntime ctx) throws JavetException {
        sourceKey = key;
        modulePath = path;
        nodeRuntime = ctx;
        queryMap = new ConcurrentHashMap<>();
        paramsMap = new ConcurrentHashMap<>();
    }

    private void func(ResultListener listener, Object... args) {
        try {
            Callable<Void> task = () -> {
                try {
                    V8ValueFunction v8ValueFunction = nodeRuntime.getGlobalObject().get("getEngine");
                    // Build V8 arguments from provided args (modulePath, query(Map/List), paramsMap)
                    Object[] callArgs = new Object[args.length];
                    for (int i = 0; i < args.length; i++) {
                        Object a = args[i];
                        if (a instanceof Map) {
                            // create V8ValueObject
                            V8ValueObject obj = nodeRuntime.createV8ValueObject();
                            Map<?,?> map = (Map<?,?>) a;
                            for (Map.Entry<?,?> entry : map.entrySet()) {
                                String k = String.valueOf(entry.getKey());
                                obj.set(k, entry.getValue());
                            }
                            callArgs[i] = obj;
                        } else if (a instanceof List) {
                            V8ValueArray arr = nodeRuntime.createV8ValueArray();
                            List<?> list = (List<?>) a;
                            for (Object item : list) arr.push(item);
                            callArgs[i] = arr;
                        } else {
                            callArgs[i] = a; // primitive (String, boolean, etc.)
                        }
                    }

                    Object result = v8ValueFunction.call(null, callArgs);

                    if (result instanceof V8ValuePromise) {
                        V8ValuePromise v8ValuePromise = ((V8ValuePromise) result);
                        v8ValuePromise.register(new IV8ValuePromise.IListener() {
                            @Override
                            public void onCatch(V8Value v8Value) {
                                try {
                                    listener.error(V8ValueConverter.stringify(V8ValueConverter.toJavaObject(v8Value)));
                                } catch (JavetException e) {
                                    listener.error(e.getMessage());
                                }
                            }

                            @Override
                            public void onFulfilled(V8Value v8Value) {
                                if (listener != null) {
                                    try {
                                        // always return Java object
                                        listener.result(V8ValueConverter.toJavaObject(v8Value));
                                    } catch (JavetException e) {
                                        listener.error(e.getMessage());
                                    }
                                }
                            }

                            @Override
                            public void onRejected(V8Value v8Value) {
                                try {
                                    listener.error(V8ValueConverter.stringify(V8ValueConverter.toJavaObject(v8Value)));
                                } catch (JavetException e) {
                                    listener.error(e.getMessage());
                                }
                            }
                        });
                    } else {
                        if (listener != null) {
                            listener.result(result);
                        }
                    }
                } catch (Throwable throwable) {
                    LOG.e(throwable);
                    if (listener != null) {
                        listener.error(throwable.getMessage());
                    }
                }
                return null;
            };
            // Submit task to runtime thread (fire-and-forget)
            NodeServerController.submitToNode(task);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) listener.error(throwable.getMessage());
        }
    }

    @Override
    public void init(Context context) throws Exception {
        super.init(context);
    }

    @Override
    public void init(Context context, String extend) throws Exception {
        super.init(context, extend);
        try {
            String ddo = "ds";
            boolean refresh = false;
            if (extend.startsWith("{")) {
                JSONObject json = new JSONObject(extend);
                extend = json.optString("extend", "");
                ddo = json.optString("do", "ds");
                refresh = json.optBoolean("refresh", false);
            }
            queryMap.put("do", ddo);
            if(refresh) queryMap.put("refresh", "");
            queryMap.put("extend", extend);

            // store into paramsMap instead of creating V8ValueObject here
            paramsMap.put("sitekey", sourceKey);
            paramsMap.put("port", Proxy.getPort());
            paramsMap.put("proxyUrl", Proxy.getUrl(true) + "?do=node&siteKey=" + sourceKey);
        } catch (Throwable throwable) {
            LOG.e(throwable);
        }
    }

    @Override
    public String categoryContent(String tid, String pg, boolean filter, HashMap<String, String> extend, ResultListener listener) {
        try {
            Map<String, Object> extMap = new HashMap<>();
            if (extend != null) {
                extMap.putAll(extend);
            }
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("ac", "category");
            query.put("t", tid);
            query.put("pg", pg);
            query.put("ext", extMap);
            func(listener, modulePath, query, paramsMap);
            return "";
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
    }

    @Override
    public String detailContent(List<String> list, ResultListener listener) {
        try {
            List<String> arr = new ArrayList<>();
            if (list != null) arr.addAll(list);
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("ac", "detail");
            query.put("ids", arr);
            func(listener, modulePath, query, paramsMap);
            return "";
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
    }

    @Override
    public String homeContent(boolean filter, ResultListener listener) {
        try {
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("filter", filter);
            func(listener, modulePath, query, paramsMap);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
        return "";
    }

    @Override
    public String homeVideoContent(ResultListener listener) {
        try {
            Map<String, Object> query = new HashMap<>(queryMap);
            func(listener, modulePath, query, paramsMap);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
        return "";
    }

    @Override
    public String playerContent(String flag, String id, List<String> vipFlags, ResultListener listener) {
        try {
            List<String> arr = new ArrayList<>();
            if (vipFlags != null) arr.addAll(vipFlags);
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("play", id);
            query.put("flag", flag);
            query.put("vipFlags", arr);
            func(listener, modulePath, query, paramsMap);
            return "";
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
    }

    @Override
    public String searchContent(String key, boolean quick, ResultListener listener) {
        try {
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("wd", key);
            query.put("quick", quick);
            func(listener, modulePath, query, paramsMap);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
        return "";
    }

    @Override
    public String searchContent(String key, boolean quick, String pg, ResultListener listener) {
        try {
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("wd", key);
            query.put("quick", quick);
            query.put("pg", pg);
            func(listener, modulePath, query, paramsMap);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
        return "";
    }

    @Override
    public String action(String action, ResultListener listener) {
        try {
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("ac", action);
            query.put("action", action);
            query.put("value", "");
            func(listener, modulePath, query, paramsMap);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
        return "";
    }

    @Override
    public String action(String action, String value, ResultListener listener) {
        try {
            Map<String, Object> query = new HashMap<>(queryMap);
            query.put("action", action);
            query.put("ac", action);
            query.put("value", value);
            func(listener, modulePath, query, paramsMap);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            listener.error(throwable.getMessage());
            return "";
        }
        return "";
    }

    @Override
    @SuppressWarnings("unchecked")
    public Object[] proxyLocal(Map< String, String > params) {
        Object[] res = new Object[4];
        try {
            Map<String, Object> query = new HashMap<>(queryMap);
            if (params != null) query.putAll(params);
            query.put("proxy", "proxy");

            CountDownLatch countDownLatch = new CountDownLatch(1);
            func(new com.github.catvod.crawler.Spider.ResultListener() {
                @Override
                public void result(Object result) {
                    //LOG.e("node代理:"+ result.toString());
                    if (result instanceof List) {
                        List<Object> rs = (List<Object>)result;
                        Map<String, String> headers = rs.size() > 3 ? (Map<String, String>) rs.get(3) : null;
                        boolean base64 = rs.size() > 4 && ((int) rs.get(4)) == 1;
                        res[0] = rs.get(0);
                        res[1] = rs.get(1);
                        res[2] = getStream(rs.get(2), base64);
                        res[3] = headers;
                        LOG.e("node代理bytes:"+ (rs.get(2) instanceof byte[]));
                    }
                    countDownLatch.countDown();
                }
            }, modulePath, query, paramsMap);
            try {
                boolean awaited = countDownLatch.await(15, TimeUnit.SECONDS);
                if (!awaited) LOG.e("源等待node代理超时");
                return res;
            } catch (InterruptedException e) {
                LOG.e("源等待node代理超时:"+ e);
                Thread.currentThread().interrupt();
            }
        } catch (Throwable throwable) {
            LOG.e(throwable);
        }
        return res;
    }

    private ByteArrayInputStream getStream(Object obj, boolean base64) {
        if (obj instanceof byte[]) {
            return new ByteArrayInputStream((byte[]) obj);
        } else {
            String content = V8ValueConverter.stringify(obj);
            if (base64 && content.contains("base64,")) content = content.split("base64,")[1];
            return new ByteArrayInputStream(base64 ? Base64.decode(content, Base64.DEFAULT | Base64.NO_WRAP) : content.getBytes());
        }
    }
}
