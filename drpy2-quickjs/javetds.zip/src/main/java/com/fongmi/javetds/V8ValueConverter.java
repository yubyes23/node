package com.fongmi.javetds;

import android.util.Base64;

import com.caoccao.javet.exceptions.JavetException;
import com.caoccao.javet.values.V8Value;
import com.caoccao.javet.values.primitive.V8ValueBoolean;
import com.caoccao.javet.values.primitive.V8ValueDouble;
import com.caoccao.javet.values.primitive.V8ValueInteger;
import com.caoccao.javet.values.primitive.V8ValueLong;
import com.caoccao.javet.values.primitive.V8ValuePrimitive;
import com.caoccao.javet.values.primitive.V8ValueString;
import com.caoccao.javet.values.primitive.V8ValueUnknown;
import com.caoccao.javet.values.primitive.V8ValueZonedDateTime;
import com.caoccao.javet.values.reference.IV8ValueArray;
import com.caoccao.javet.values.reference.IV8ValueObject;
import com.caoccao.javet.values.reference.V8ValueArray;
import com.caoccao.javet.values.reference.V8ValueArrayBuffer;
import com.caoccao.javet.values.reference.V8ValueObject;
import com.caoccao.javet.values.reference.V8ValueTypedArray;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class V8ValueConverter {
    /**
     * Convert a Spider result (Java object) into a String.
     * - If null -> null
     * - If String -> returned as-is
     * - If byte[] -> base64 string
     * - If Map/List -> JSON string
     * - Otherwise -> String.valueOf(obj)
     */
    public static String stringify(Object obj) {
        if (obj == null) return null;
        if (obj instanceof String) return (String) obj;
        if (obj instanceof byte[]) return Base64.encodeToString((byte[]) obj, Base64.NO_WRAP);
        if (obj instanceof Map) {
            try {
                return new JSONObject((Map<?,?>) obj).toString();
            } catch (Exception e) {
                return String.valueOf(obj);
            }
        }
        if (obj instanceof List) {
            try {
                return new JSONArray((List<?>) obj).toString();
            } catch (Exception e) {
                return String.valueOf(obj);
            }
        }
        return String.valueOf(obj);
    }

    // V8Value → Java Object
    public static Object toJavaObject(V8Value v8Value) throws JavetException {
        if (v8Value == null) return null;
        // Use a visited set to detect cycles during recursion
        Set<Integer> visited = new HashSet<>();
        return toJavaObjectInternal(v8Value, visited);
    }

    // Internal recursive implementation with cycle detection and single-close ownership of the passed v8Value
    private static Object toJavaObjectInternal(V8Value v8Value, Set<Integer> visited) throws JavetException {
        if (v8Value == null) return null;

        // We'll close the passed v8Value exactly once here in the finally block.
        try {
            if (v8Value.isUndefined() || v8Value.isNull()) {
                return null;
            }

            if (v8Value instanceof V8ValuePrimitive) {
                if (v8Value instanceof V8ValueString) {
                    return ((V8ValueString) v8Value).getValue();
                }
                if (v8Value instanceof V8ValueInteger) {
                    return ((V8ValueInteger) v8Value).getValue();
                }
                if (v8Value instanceof V8ValueDouble) {
                    return ((V8ValueDouble) v8Value).getValue();
                }
                if (v8Value instanceof V8ValueBoolean) {
                    return ((V8ValueBoolean) v8Value).getValue();
                }
                if (v8Value instanceof V8ValueLong) {
                    return ((V8ValueLong) v8Value).getValue();
                }
                if (v8Value instanceof V8ValueZonedDateTime) {
                    return v8Value.toString();
                }
                if (v8Value instanceof V8ValueUnknown) {
                    return v8Value.toString();
                }
            }

            // Direct binary types
            if (v8Value instanceof V8ValueTypedArray) {
                return extractBytes((V8ValueTypedArray) v8Value);
            }
            if (v8Value instanceof V8ValueArrayBuffer) {
                return extractBytes((V8ValueArrayBuffer) v8Value);
            }

            if (v8Value instanceof V8ValueArray) {
                int id = System.identityHashCode(v8Value);
                if (visited.contains(id)) return "[Circular]";
                visited.add(id);

                V8ValueArray array = (V8ValueArray) v8Value;
                List<Object> list = new ArrayList<>();
                for (int i = 0; i < array.getLength(); i++) {
                    V8Value child = array.get(i);
                    if (child == null) {
                        list.add(null);
                    } else {
                        try {
                            list.add(toJavaObjectInternal(child, visited));
                        } finally {
                            try { child.close(); } catch (Throwable ignored) {}
                        }
                    }
                }
                visited.remove(id);
                return list;
            }

            if (v8Value instanceof V8ValueObject) {
                int id = System.identityHashCode(v8Value);
                if (visited.contains(id)) return "[Circular]";
                visited.add(id);

                V8ValueObject obj = (V8ValueObject) v8Value;

                // Detect binary by type or properties
                if (isBinary(obj)) {
                    byte[] bytes = extractBytes(obj);
                    visited.remove(id);
                    return bytes;
                }

                // 普通对象转 Map
                Map<String, Object> map = new HashMap<>();
                IV8ValueArray keys = null;
                try {
                    keys = obj.getOwnPropertyNames();
                    for (int i = 0; i < keys.getLength(); i++) {
                        String key = keys.getString(i);
                        V8Value child = obj.get(key);
                        if (child == null) {
                            map.put(key, null);
                        } else {
                            try {
                                map.put(key, toJavaObjectInternal(child, visited));
                            } finally {
                                try { child.close(); } catch (Throwable ignored) {}
                            }
                        }
                    }
                } finally {
                    if (keys != null) try { keys.close(); } catch (Throwable ignored) {}
                }

                visited.remove(id);
                return map;
            }

            // Fallback: return string representation
            return v8Value.toString();
        } finally {
            // 关闭传入的顶层引用，防止调用方未关闭导致 native 内存泄漏
            try { v8Value.close(); } catch (Throwable ignored) {}
        }
    }

    private static boolean isBinary(IV8ValueObject obj) {
        // TypedArray/ArrayBuffer/Buffer-like objects通常有这些属性，或者直接是相应的实现类
        try {
            if (obj instanceof V8ValueTypedArray) return true;
            if (obj instanceof V8ValueArrayBuffer) return true;
            if (obj.has("byteLength")) return true;
            if (obj.has("buffer")) return true;
            if (obj.has("BYTES_PER_ELEMENT")) return true;
            // Node Buffer often has type === 'Buffer' and 'data' field
            if (obj.has("type")) {
                V8Value t = obj.get("type");
                try {
                    if (t instanceof V8ValueString) {
                        String s = ((V8ValueString) t).getValue();
                        if ("Buffer".equals(s)) return true;
                    }
                } finally {
                    if (t != null) try { t.close(); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static byte[] extractBytes(V8ValueTypedArray typedArray) throws JavetException {
        return typedArray.toBytes();
    }

    private static byte[] extractBytes(V8ValueArrayBuffer buffer) {
        return buffer.toBytes();
    }

    private static byte[] extractBytes(V8ValueObject buffer) throws JavetException {
        if (buffer instanceof V8ValueTypedArray) {
            return extractBytes((V8ValueTypedArray) buffer);
        }
        if (buffer instanceof V8ValueArrayBuffer) {
            return extractBytes((V8ValueArrayBuffer) buffer);
        }
        // Node Buffer 或其他带 data 字段的情况，尝试读取常见方式
        if (buffer.has("toArrayBuffer")) {
            V8Value ab = buffer.get("toArrayBuffer");
            if (ab != null) {
                try {
                    if (ab instanceof V8ValueArrayBuffer) {
                        return extractBytes((V8ValueArrayBuffer) ab);
                    }
                    // 有些实现返回一个 TypedArray
                    if (ab instanceof V8ValueTypedArray) {
                        return extractBytes((V8ValueTypedArray) ab);
                    }
                } finally {
                    try { ab.close(); } catch (Throwable ignored) {}
                }
            }
        }
        if (buffer.has("data")) {
            V8Value data = buffer.get("data");
            if (data != null) {
                try {
                    if (data instanceof V8ValueTypedArray) {
                        return extractBytes((V8ValueTypedArray) data);
                    }
                    if (data instanceof V8ValueArrayBuffer) {
                        return extractBytes((V8ValueArrayBuffer) data);
                    }
                    if (data instanceof V8ValueArray) {
                        V8ValueArray da = (V8ValueArray) data;
                        int len = da.getLength();
                        byte[] out = new byte[len];
                        for (int i = 0; i < len; i++) {
                            V8Value item = da.get(i);
                            try {
                                String s = item == null ? "0" : item.toString();
                                int iv;
                                try {
                                    iv = Integer.parseInt(s);
                                } catch (NumberFormatException nfe) {
                                    try {
                                        iv = (int) Double.parseDouble(s);
                                    } catch (NumberFormatException nfe2) {
                                        iv = 0;
                                    }
                                }
                                out[i] = (byte) iv;
                            } catch (Throwable ignored) {
                                out[i] = 0;
                            } finally {
                                if (item != null) try { item.close(); } catch (Throwable ignored) {}
                            }
                        }
                        return out;
                    }
                } finally {
                    try { data.close(); } catch (Throwable ignored) {}
                }
            }
        }
        // 如果对象本身有 length 和按索引访问的属性，也尝试按索引读取
        if (buffer.has("length")) {
            V8Value lenVal = null;
            try {
                lenVal = buffer.get("length");
                if (lenVal != null) {
                    int len;
                    try {
                        String ls = lenVal.toString();
                        len = Integer.parseInt(ls);
                    } catch (Throwable t) {
                        len = 0;
                    }
                    if (len > 0) {
                        byte[] out = new byte[len];
                        for (int i = 0; i < len; i++) {
                            V8Value item = null;
                            try {
                                item = buffer.get(String.valueOf(i));
                                if (item != null) {
                                    try {
                                        String s = item.toString();
                                        int iv;
                                        try {
                                            iv = Integer.parseInt(s);
                                        } catch (NumberFormatException nfe) {
                                            try { iv = (int) Double.parseDouble(s); } catch (NumberFormatException nfe2) { iv = 0; }
                                        }
                                        out[i] = (byte) iv;
                                    } finally {
                                        try { item.close(); } catch (Throwable ignored) {}
                                    }
                                } else {
                                    out[i] = 0;
                                }
                            } catch (Throwable ignored) {
                                out[i] = 0;
                                try { if (item != null) item.close(); } catch (Throwable ignored2) {}
                            }
                        }
                        return out;
                    }
                }
            } finally {
                if (lenVal != null) try { lenVal.close(); } catch (Throwable ignored) {}
            }
        }
        return null;
    }
}

