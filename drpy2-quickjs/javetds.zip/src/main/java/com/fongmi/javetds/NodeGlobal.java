package com.fongmi.javetds;

import androidx.annotation.Keep;

import com.caoccao.javet.annotations.V8Function;
import com.github.catvod.Proxy;

public class NodeGlobal {
    @Keep
    @V8Function
    public String getProxy(Boolean local) {
        return Proxy.getUrl(local) + "?do=node";
    }

}
