
process.reallyExit = function(code) {
	console.log('[DS]', 'Process exit is suppressed.');
};
process.on('uncaughtException', (error) => {
	console.error('[DS]', 'uncaughtException:', error);
});
process.on('unhandledRejection', (reason, promise) => {
	console.error('[DS]', 'unhandledRejection:', reason);
});
// 拦截器优化最终版
            const setupStreamHooks = () => {
                const originals = {
                    stdout: process.stdout.write.bind(process.stdout),
                    stderr: process.stderr.write.bind(process.stderr)
                };

                const trimTrailing = (input) => {
                    // 判断是否为 Buffer 类型
                    if (Buffer.isBuffer(input)) {
                        // 直接截取 Buffer
                        let end = input.length;
                        while (end > 0 && (input[end - 1] === 10 || input[end - 1] === 13)) {
                            end--;
                        }
                        return input.slice(0, end).toString();
                    }
                    // 判断是否为字符串类型
                    else if (typeof input === 'string') {
                        // 方法 2：字符串处理
                        return input.replace(/[\r\n]+$/, "");
                    }
                    // 其他类型抛出错误
                    else {
                        throw new TypeError("Input must be a Buffer or String");
                    }
                };

                let inHook = false;

                const createHook = (method, original) => (buffer, encoding, callback) => {
                    if (inHook) return original(buffer, encoding, callback);

                    try {
                        inHook = true;
                        //hooklog(method, trimTrailing(buffer));
                        if(method == 'error'){
                            console.error(trimTrailing(buffer));
                        } else {
                            console.log(trimTrailing(buffer));
                        }

                    } catch (e) {
                        originals.stderr(`Hook error: ${e.stack || e.message}\n`, 'utf8');
                    } finally {
                        inHook = false;
                    }

                    const enc = typeof encoding === 'string' ? encoding : 'utf8';
                    const cb = typeof callback === 'function' ? callback : typeof encoding === 'function' ? encoding : undefined;

                    return original(buffer, enc, cb);
                };

                process.stdout.write = createHook('info', originals.stdout);
                process.stderr.write = createHook('error', originals.stderr);
            };

            setupStreamHooks();
const vm = require('node:vm');
const path = require('node:path');
const url = require('node:url');
const globalImport = function(modulePath, metaUrl) {
	if(metaUrl){
		modulePath = path.join(metaUrl, modulePath);
	}

	const script = new vm.Script("import(" + JSON.stringify(modulePath) + ")", {
		importModuleDynamically: vm.constants.USE_MAIN_CONTEXT_DEFAULT_LOADER
	});
	
	return script.runInNewContext();
};
globalThis.import = globalImport;
globalThis.__createGlobalImport__ = function(metaUrl){
	metaUrl = path.dirname(url.fileURLToPath(metaUrl));
	let GlobalImport=function(modulePath){
		return globalImport(modulePath, metaUrl);
	};
	return new Proxy(globalThis,{
		get(target, key, receiver){
			if(key==="import"&&target[key]===globalImport){
				return GlobalImport;
			}
			return target[key];
		},
		set(target, key,value, receiver){
			target[key] = value;
			return true;
		}
	});
};
globalThis.fetchByHiker = function(url, options) {
	return null;
};
process.env["ANDROID_APP_NAME"]='影图';
process.env["IS_HIKER"]="1";

