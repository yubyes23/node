package com.fongmi.android.tv.model;

import static com.fongmi.android.tv.downloader.down.service.DownService.checkCached;

import android.net.Uri;
import android.text.TextUtils;

import androidx.collection.ArrayMap;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.fongmi.android.tv.App;
import com.fongmi.android.tv.Constant;
import com.fongmi.android.tv.R;
import com.fongmi.android.tv.api.config.VodConfig;
import com.fongmi.android.tv.bean.Danmu;
import com.fongmi.android.tv.bean.Episode;
import com.fongmi.android.tv.bean.Flag;
import com.fongmi.android.tv.bean.History;
import com.fongmi.android.tv.bean.Result;
import com.fongmi.android.tv.bean.Site;
import com.fongmi.android.tv.bean.Url;
import com.fongmi.android.tv.bean.Vod;
import com.fongmi.android.tv.exception.ExtractException;
import com.fongmi.android.tv.player.Source;
import com.fongmi.android.tv.utils.ResUtil;
import com.fongmi.android.tv.utils.Sniffer;
import com.fongmi.javetds.V8ValueConverter;
import com.caoccao.javet.values.V8Value;
import com.github.catvod.crawler.Spider;
import com.github.catvod.crawler.SpiderDebug;
import com.github.catvod.net.OkHttp;
import com.github.catvod.utils.Path;
import com.github.catvod.utils.Util;
import com.github.catvod.utils.log.LOG;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Headers;
import okhttp3.Response;

public class SiteViewModel extends ViewModel {

    private final ExecutorService executor;
    private Future<Result> future;

    public MutableLiveData<Episode> epDownLoad;
    public MutableLiveData<Episode> epCast;
    public MutableLiveData<Episode> episode;
    public MutableLiveData<Result> result;
    public MutableLiveData<Result> player;
    public MutableLiveData<Result> cast;
    public MutableLiveData<Result> search;
    public MutableLiveData<Danmu> danmaku;
    public MutableLiveData<Result> action;

    public SiteViewModel() {
        this.epDownLoad = new MutableLiveData<>();
        this.epCast = new MutableLiveData<>();
        this.episode = new MutableLiveData<>();
        this.result = new MutableLiveData<>();
        this.player = new MutableLiveData<>();
        this.cast = new MutableLiveData<>();
        this.search = new MutableLiveData<>();
        this.action = new MutableLiveData<>();
        executor = Executors.newSingleThreadExecutor();

    }

    public void setEpisode(Episode value) {
        episode.setValue(value);
    }

    public void setDownload(Episode value) {
        epDownLoad.setValue(value);
    }

    public void setCast(Episode value) {
        epCast.setValue(value);
    }

    public void homeContent() {
        if (VodConfig.get().getHome().getType() == 5) {
            executor.execute(() -> {
                try {
                    Site site = VodConfig.get().getHome();
                    Spider spider = VodConfig.get().getSpider(site);
                    VodConfig.get().setRecent(site);
                    spider.homeContent(true, new Spider.ResultListener() {
                        @Override
                        public void result(Object res) {
                            try {
                                LOG.e("NODE_home", res == null ? "null" : res.toString());
                                Object nodeObj;
                                if (res instanceof V8Value) {
                                    nodeObj = V8ValueConverter.toJavaObject((V8Value) res);
                                } else nodeObj = res;
                                result.postValue(Result.fromJson(V8ValueConverter.stringify(nodeObj)));
                            } catch (Throwable e) {
                                if (e.getCause() instanceof ExtractException)
                                    result.postValue(Result.error(e.getCause().getMessage()));
                                else result.postValue(Result.empty());
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void error(String msg) {
                            result.postValue(Result.error(msg));
                        }

                    });
                } catch (Exception e) {
                    result.postValue(Result.error(e.getMessage()));
                }
            });
        } else {
            execute(result, () -> {
                Site site = VodConfig.get().getHome();
                if (site.getType() == 3) {
                    Spider spider = VodConfig.get().getSpider(site);
                    String homeContent = spider.homeContent(true);
                    SpiderDebug.log(site.getName() + " -- homeContent", homeContent);
                    VodConfig.get().setRecent(site);
                    Result result = Result.fromJson(homeContent);
                    if (!result.getList().isEmpty()) return result;
                    String homeVideoContent = spider.homeVideoContent();
                    SpiderDebug.log(site.getName() + " -- homeVideoContent", homeVideoContent);
                    result.setList(Result.fromJson(homeVideoContent).getList());
                    return result;
                } else if (site.getType() == 4) {
                    ArrayMap<String, String> params = new ArrayMap<>();
                    params.put("filter", "true");
                    String homeContent = call(site, params, false);
                    SpiderDebug.log(site.getName() + " -- homeContent", homeContent);
                    return Result.fromJson(homeContent);
                } else {
                    String homeContent = OkHttp.newCall(site.getApi(), site.getHeaders()).execute().body().string();
                    SpiderDebug.log(site.getName() + " -- homeContent", homeContent);
                    return fetchPic(site, Result.fromType(site.getType(), homeContent));
                }
            });
        }
    }

    public void categoryContent(String key, String tid, String page, boolean filter, HashMap<String, String> extend) {
        if (VodConfig.get().getSite(key).getType() == 5) {
            executor.execute(() -> {
                try {
                    Site site = VodConfig.get().getSite(key);
                    Spider spider = VodConfig.get().getSpider(site);
                    VodConfig.get().setRecent(site);
                    spider.categoryContent(tid, page, filter, extend, new Spider.ResultListener() {
                        @Override
                        public void result(Object res) {
                            try {
                                LOG.e("NODE_category", res == null ? "null" : res.toString());
                                Object nodeObj;
                                if (res instanceof V8Value) {
                                    nodeObj = V8ValueConverter.toJavaObject((V8Value) res);
                                } else nodeObj = res;
                                result.postValue(Result.fromJson(V8ValueConverter.stringify(nodeObj)));
                            } catch (Throwable e) {
                                if (e.getCause() instanceof ExtractException)
                                    result.postValue(Result.error(e.getCause().getMessage()));
                                else result.postValue(Result.empty());
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void error(String msg) {
                            result.postValue(Result.error(msg));
                        }

                    });
                } catch (Exception e) {
                    result.postValue(Result.error(e.getMessage()));
                }
            });
        } else {
            execute(result, () -> {
                Site site = VodConfig.get().getSite(key);
                if (site.getType() == 3) {
                    Spider spider = VodConfig.get().getSpider(site);
                    String categoryContent = spider.categoryContent(tid, page, filter, extend);
                    SpiderDebug.log(site.getName() + " -- categoryContent", categoryContent);
                    VodConfig.get().setRecent(site);
                    return Result.fromJson(categoryContent);
                } else {
                    ArrayMap<String, String> params = new ArrayMap<>();
                    if (site.getType() == 1 && !extend.isEmpty())
                        params.put("f", App.gson().toJson(extend));
                    else if (site.getType() == 4)
                        params.put("ext", Util.base64(App.gson().toJson(extend)));
                    params.put("ac", site.getType() == 0 ? "videolist" : "detail");
                    params.put("t", tid);
                    params.put("pg", page);
                    String categoryContent = call(site, params, true);
                    SpiderDebug.log(site.getName() + " -- categoryContent", categoryContent);
                    return Result.fromType(site.getType(), categoryContent);
                }
            });
        }
    }

    public void detailContent(String key, String id) {
        if (VodConfig.get().getSite(key).getType() == 5) {
            executor.execute(() -> {
                try {
                    Site site = VodConfig.get().getSite(key);
                    Spider spider = VodConfig.get().getSpider(site);
                    VodConfig.get().setRecent(site);
                    spider.detailContent(Collections.singletonList(id), new Spider.ResultListener() {
                        @Override
                        public void result(Object res) {
                            try {
                                LOG.e("NODE_detail", res == null ? "null" : res.toString());
                                Object nodeObj;
                                if (res instanceof V8Value) {
                                    nodeObj = V8ValueConverter.toJavaObject((V8Value) res);
                                } else nodeObj = res;
                                Result ret = Result.fromJson(V8ValueConverter.stringify(nodeObj));
                                if (!ret.getList().isEmpty()) ret.getList().get(0).setVodFlags();
                                if (!ret.getList().isEmpty())
                                    Source.get().parse(ret.getList().get(0).getVodFlags());
                                result.postValue(ret);
                            } catch (Throwable e) {
                                if (e.getCause() instanceof ExtractException)
                                    result.postValue(Result.error(e.getCause().getMessage()));
                                else result.postValue(Result.empty());
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void error(String msg) {
                            result.postValue(Result.error(msg));
                        }

                    });
                } catch (Exception e) {
                    result.postValue(Result.error(e.getMessage()));
                }
            });
        } else {
            execute(result, () -> {
                Site site = VodConfig.get().getSite(key);
                if (site.getType() == 3) {
                    Spider spider = VodConfig.get().getSpider(site);
                    String detailContent = spider.detailContent(Collections.singletonList(id));
                    SpiderDebug.log(site.getName() + " -- detailContent", detailContent);
                    VodConfig.get().setRecent(site);
                    Result result = Result.fromJson(detailContent);
                    if (!result.getList().isEmpty()) result.getList().get(0).setVodFlags();
                    if (!result.getList().isEmpty())
                        Source.get().parse(result.getList().get(0).getVodFlags());
                    return result;
                } else if (site.isEmpty() && "push_agent".equals(key)) {
                    Vod vod = new Vod();
                    vod.setVodId(id);
                    vod.setVodName(id);
                    VodConfig.get().setRecent(site);
                    vod.setVodPic(ResUtil.getString(R.string.push_image));
                    vod.setVodFlags(Flag.create(ResUtil.getString(R.string.push), ResUtil.getString(R.string.play), id));
                    Source.get().parse(vod.getVodFlags());
                    return Result.vod(vod);
                } else {
                    ArrayMap<String, String> params = new ArrayMap<>();
                    params.put("ac", site.getType() == 0 ? "videolist" : "detail");
                    params.put("ids", id);
                    String detailContent = call(site, params, true);
                    SpiderDebug.log(site.getName() + " -- detailContent", detailContent);
                    VodConfig.get().setRecent(site);
                    Result result = Result.fromType(site.getType(), detailContent);
                    if (!result.getList().isEmpty()) result.getList().get(0).setVodFlags();
                    if (!result.getList().isEmpty())
                        Source.get().parse(result.getList().get(0).getVodFlags());
                    return result;
                }
            });
        }
    }

    private void playerContent(MutableLiveData<Result> data, String key, String flag, String id, History history) {
        if (VodConfig.get().getSite(key).getType() == 5) {
            executor.execute(() -> {
                try {
                    Source.get().stop();
                    Site site = VodConfig.get().getSite(key);
                    if (history != null && !id.startsWith("/")) {
                        Result result1 = new Result();
                        String localurl = checkCached(history.getVodName(), history.getVodRemarks());
                        if (localurl != null) {
                            result1.setUrl(new Url().add("file://" + localurl));
                            result1.setKey(key);
                            result1.setHeader(site.getHeader());
                            result1.setFlag(history.getVodFlag());
                            result1.setJx(0);
                            result1.setParse(0);
                            data.postValue(result1);
                        }
                    }
                    Spider spider = VodConfig.get().getSpider(site);
                    VodConfig.get().setRecent(site);
                    spider.playerContent(flag, id, VodConfig.get().getFlags(), new Spider.ResultListener() {
                        @Override
                        public void result(Object res) {
                            try {

                                Object nodeObj;
                                if (res instanceof V8Value) {
                                    nodeObj = V8ValueConverter.toJavaObject((V8Value) res);
                                } else nodeObj = res;
                                Result ret = Result.fromJson(V8ValueConverter.stringify(nodeObj));
                                if (ret.getFlag().isEmpty()) ret.setFlag(flag);
                                ret.setHeader(site.getHeader());
                                ret.setUrl(Source.get().fetch(ret));
                                ret.setKey(key);
                                data.postValue(ret);
                            } catch (Throwable e) {
                                if (e.getCause() instanceof ExtractException)
                                    data.postValue(Result.error(e.getCause().getMessage()));
                                else data.postValue(Result.empty());
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void error(String msg) {
                            data.postValue(Result.error(msg));
                        }

                    });
                } catch (Exception e) {
                    data.postValue(Result.error(e.getMessage()));
                }
            });
        } else {
            execute(data, () -> {
                Source.get().stop();
                Site site = VodConfig.get().getSite(key);
                if (history != null && !id.startsWith("/")) {
                    Result result1 = new Result();
                    String localurl = checkCached(history.getVodName(), history.getVodRemarks());
                    if (localurl != null) {
                        result1.setUrl(new Url().add("file://" + localurl));
                        result1.setKey(key);
                        result1.setHeader(site.getHeader());
                        result1.setFlag(history.getVodFlag());
                        result1.setJx(0);
                        result1.setParse(0);
                        return result1;
                    }
                }
                if (site.getType() == 3) {
                    Spider spider = VodConfig.get().getSpider(site);
                    String playerContent = spider.playerContent(flag, id, VodConfig.get().getFlags());
                    SpiderDebug.log(site.getName() + " -- playerContent", playerContent);
                    VodConfig.get().setRecent(site);
                    Result result = Result.fromJson(playerContent);
                    if (result.getFlag().isEmpty()) result.setFlag(flag);
                    result.setHeader(site.getHeader());
                    result.setUrl(Source.get().fetch(result));
                    result.setKey(key);
                    return result;
                } else if (site.getType() == 4) {
                    ArrayMap<String, String> params = new ArrayMap<>();
                    params.put("play", id);
                    params.put("flag", flag);
                    String playerContent = call(site, params, true);
                    SpiderDebug.log(site.getName() + " -- playerContent", playerContent);
                    Result result = Result.fromJson(playerContent);
                    if (result.getFlag().isEmpty()) result.setFlag(flag);
                    result.setHeader(site.getHeader());
                    result.setUrl(Source.get().fetch(result));
                    return result;
                } else if (site.isEmpty() && "push_agent".equals(key)) {
                    Result result = new Result();
                    result.setParse(0);
                    result.setFlag(flag);
                    result.setUrl(Url.create().add(id));
                    result.setUrl(Source.get().fetch(result));
                    return result;
                } else {
                    Url url = Url.create().add(id);
                    String type = Uri.parse(id).getQueryParameter("type");
                    Result result = new Result();
                    result.setHeader(site.getHeader());
                    if ("json".equals(type))
                        url = Result.fromJson(OkHttp.newCall(id, Headers.of(result.getHeaders())).execute().body().string()).getUrl();
                    result.setUrl(url);
                    result.setFlag(flag);
                    result.setPlayUrl(site.getPlayUrl());
                    result.setParse(Sniffer.isVideoFormat(url.v()) && result.getPlayUrl().isEmpty() ? 0 : 1);
                    SpiderDebug.log(site.getName() + " -- playerContent", result.toString());
                    return result;
                }
            });
        }
    }

    public void action(String key, String action) {
        if (VodConfig.get().getSite(key).getType() == 5) {
            executor.execute(() -> {
                try {
                    Site site = VodConfig.get().getSite(key);
                    Spider spider = VodConfig.get().getSpider(site);
                    spider.action(action, new Spider.ResultListener() {
                        @Override
                        public void result(Object res) {
                            try {
                                Object nodeObj;
                                if (res instanceof V8Value) {
                                    nodeObj = V8ValueConverter.toJavaObject((V8Value) res);
                                } else nodeObj = res;
                                result.postValue(Result.fromJson(V8ValueConverter.stringify(nodeObj)));
                            } catch (Throwable e) {
                                if (e.getCause() instanceof ExtractException)
                                    result.postValue(Result.error(e.getCause().getMessage()));
                                else result.postValue(Result.empty());
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void error(String msg) {
                            result.postValue(Result.error(msg));
                        }

                    });
                } catch (Exception e) {
                    result.postValue(Result.error(e.getMessage()));
                }
            });
        } else {
            execute(this.action, () -> {
                Site site = VodConfig.get().getSite(key);
                if (site.getType() == 3)
                    return Result.fromJson(VodConfig.get().getSpider(site).action(action));
                if (site.getType() == 4) return Result.fromJson(OkHttp.string(action));
                return Result.empty();
            });
        }
    }

    public void cast(String key, String flag, String id) {
        playerContent(cast, key, flag, id, null);
    }

    public void playerContent(String key, String flag, String id, History history) {
        playerContent(player, key, flag, id, history);
    }

    public void searchContent(Site site, String keyword, boolean quick, String page) throws Throwable {
        boolean hasPage = !page.equals("1");
        if (site.getType() == 5) {
            try {
                Spider spider = VodConfig.get().getSpider(site);
                if(hasPage) {
                    spider.searchContent(keyword, quick, page, new Spider.ResultListener() {
                        @Override
                        public void result(Object res) {
                            try {
                                Object nodeObj;
                                if (res instanceof V8Value) {
                                    nodeObj = V8ValueConverter.toJavaObject((V8Value) res);
                                } else nodeObj = res;
                                result.postValue(Result.fromJson(V8ValueConverter.stringify(nodeObj)));
                            } catch (Throwable e) {
                                if (e.getCause() instanceof ExtractException)
                                    result.postValue(Result.error(e.getCause().getMessage()));
                                else result.postValue(Result.empty());
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void error(String msg) {
                            result.postValue(Result.error(msg));
                        }

                    });
                } else {
                    spider.searchContent(keyword, quick, new Spider.ResultListener() {
                        @Override
                        public void result(Object res) {
                            try {
                                Object nodeObj;
                                if (res instanceof V8Value) {
                                    nodeObj = V8ValueConverter.toJavaObject((V8Value) res);
                                } else nodeObj = res;
                                result.postValue(Result.fromJson(V8ValueConverter.stringify(nodeObj)));
                            } catch (Throwable e) {
                                if (e.getCause() instanceof ExtractException)
                                    result.postValue(Result.error(e.getCause().getMessage()));
                                else result.postValue(Result.empty());
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void error(String msg) {
                            result.postValue(Result.error(msg));
                        }

                    });
                }
            } catch (Exception e) {
                result.postValue(Result.error(e.getMessage()));
            }
        } else if (site.getType() == 3) {
            Spider spider = VodConfig.get().getSpider(site);
            String searchContent = hasPage ? spider.searchContent(keyword, quick, page) : spider.searchContent(keyword, quick);
            SpiderDebug.log(site.getName() + " -- searchContent", searchContent);
            post(site, Result.fromJson(searchContent), hasPage);
        } else {
            ArrayMap<String, String> params = new ArrayMap<>();
            params.put("wd", keyword);
            params.put("quick", String.valueOf(quick));
            params.put("extend", "");
            if (hasPage) params.put("pg", page);
            String searchContent = call(site, params, true);
            SpiderDebug.log(site.getName() + " -- searchContent", searchContent);
            post(site, fetchPic(site, Result.fromType(site.getType(), searchContent)), hasPage);
        }
    }

    public static String call(Site site, ArrayMap<String, String> params, boolean limit) throws IOException {
        Call call = fetchExt(site, params, limit).length() <= 1000 ? OkHttp.newCall(site.getApi(), site.getHeaders(), params) : OkHttp.newCall(site.getApi(), site.getHeaders(), OkHttp.toBody(params));
        return call.execute().body().string();
    }

    private static String fetchExt(Site site, ArrayMap<String, String> params, boolean limit) throws IOException {
        String extend = site.getExt();
        if (extend.startsWith("http://127.0.0.1"))
            extend = URLEncoder.encode(getFixUrl(extend), "UTF-8");
        site.setExt(extend);
        if (limit && extend.length() > 1000) extend = extend.substring(0, 1000);
        if (!extend.isEmpty()) params.put("extend", extend);
        return extend;
    }

    private static String getFixUrl(String content) {
        String path = content.replaceAll("^http.+/file/", Path.rootPath() + "/");
        path = path.replaceAll("localhost/", "/");
        return Path.read(path);
    }

    private Result fetchPic(Site site, Result result) throws Exception {
        if (site.getType() > 2 || result.getList().isEmpty() || !result.getList().get(0).getVodPic().isEmpty())
            return result;
        ArrayList<String> ids = new ArrayList<>();
        boolean empty = site.getCategories().isEmpty();
        for (Vod item : result.getList())
            if (empty || site.getCategories().contains(item.getTypeName()))
                ids.add(item.getVodId());
        if (ids.isEmpty()) return result.clear();
        ArrayMap<String, String> params = new ArrayMap<>();
        params.put("ac", site.getType() == 0 ? "videolist" : "detail");
        params.put("ids", TextUtils.join(",", ids));
        try (Response response = OkHttp.newCall(site.getApi(), site.getHeaders(), params).execute()) {
            result.setList(Result.fromType(site.getType(), response.body().string()).getList());
            return result;
        }
    }

    private void post(Site site, Result result, Boolean haspage) {
        //if (result.getList().isEmpty()) return;
        for (Vod vod : result.getList()) vod.setSite(site);
        if (haspage) this.result.postValue(result);
        else this.search.postValue(result);
    }

    private void execute(MutableLiveData<Result> result, Callable<Result> callable) {
        if (future != null && !future.isDone()) future.cancel(true);
        future = App.submit(callable);
        executor.execute(() -> {
            try {
                Result taskResult = future.get(Constant.TIMEOUT_VOD, TimeUnit.MILLISECONDS);
                if (future.isCancelled()) return;
                result.postValue(taskResult);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Throwable e) {
                if (future.isCancelled()) return;
                if (e.getCause() instanceof ExtractException)
                    result.postValue(Result.error(e.getCause().getMessage()));
                else result.postValue(Result.empty());
                e.printStackTrace();
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (future != null) future.cancel(true);
        if (executor != null) executor.shutdownNow();
    }
}
